#set( $FULLNAME = "${USER}" )
