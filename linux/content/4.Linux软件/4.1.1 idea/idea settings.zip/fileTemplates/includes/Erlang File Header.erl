#parse("Erlang Custom Template Variables.erl")
%%%-------------------------------------------------------------------
%%% @author ${FULLNAME}
%%% @doc
%%%
%%% Created : ${DAY}. ${MONTH_NAME_SHORT} ${YEAR} ${TIME}
%%%-------------------------------------------------------------------
