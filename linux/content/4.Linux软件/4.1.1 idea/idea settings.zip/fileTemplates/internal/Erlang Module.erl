#parse("Erlang File Header.erl")
-module(${NAME_ATOM}).
#parse("Erlang File Module.erl")

-export([]).
