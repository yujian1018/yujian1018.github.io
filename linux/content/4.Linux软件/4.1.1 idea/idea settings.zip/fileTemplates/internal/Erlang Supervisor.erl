#parse("Erlang File Header.erl")
-module(${NAME_ATOM}).
#parse("Erlang File Module.erl")

-behaviour(supervisor).

-export([start_link/0, init/1]).


-export([
    start_child/3,
    stop_child/1
]).

-define(SERVER, ?MODULE).
-define(CHILD(RegName, SrvMod, Type, Arg), {RegName, {SrvMod, start_link, Arg}, permanent, 5000, Type, [SrvMod]}).


start_link() ->
    supervisor:start_link({local, ?SERVER}, ?MODULE, []).


init([]) ->
    {ok, {{one_for_one, 5, 10}, []}}.


start_child(RegName, SrvMod, Arg) ->
    supervisor:start_child(?SERVER, ?CHILD(RegName, SrvMod, worker, [RegName, Arg])).


stop_child(RegName) ->
    supervisor:terminate_child(?SERVER, RegName),
    supervisor:delete_child(?SERVER, RegName).
